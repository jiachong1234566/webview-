//
//  RNCachingURLProtocol.h
//  DaboPlayer
//
//  Created by 贾崇 on 16/10/27.
//  Copyright © 2016年 dabo. All rights reserved.
//

#import <Foundation/Foundation.h>

static NSString *JCCachingURLHeader = @"X-RNCache";

@interface JCCachingURLProtocol : NSURLProtocol

- (BOOL)useCache;
- (NSString *)cachePathForRequest:(NSURLRequest *)aRequest;

+ (NSSet *)supportedSchemes;
+ (void)setSupportedSchemes:(NSSet *)supportedSchemes;

@end
